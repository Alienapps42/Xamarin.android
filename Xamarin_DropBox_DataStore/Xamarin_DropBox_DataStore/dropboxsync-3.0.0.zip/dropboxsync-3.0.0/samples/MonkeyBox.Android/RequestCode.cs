using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using DropboxSync.Android;
using Android.Accounts;

namespace MonkeyBox.Android
{
	enum RequestCode
	{
        LinkToDropboxRequest
	}
}


